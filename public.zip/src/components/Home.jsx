import React from 'react'
import Header from './Header'
// import Freelance from './Freelance'

const Home = () => {
  return (
    <>
    <Header/>
    {/* <Freelance/> */}
    </>
  )
}

export default Home