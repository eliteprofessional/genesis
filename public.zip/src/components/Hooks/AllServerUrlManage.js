// server url all
export const serverUrl = "http://localhost:8080/api/v1";
export const serverRoot = "http://localhost:8080/";

// export const serverRoot = "https://hire.server.elite-professionals.in/";
// export const serverUrl = "https://hire.server.elite-professionals.in/api/v1";

// export const serverUrl = "https://elitepro-hi-re-backend.vercel.app/api/v1";
// export const serverRoot = "https://elitepro-hi-re-backend.vercel.app/";

// live site url all
export const liveSiteUrl = "http://www.hire.elite-professionals.in";
// export const liveSiteUrl = "http://localhost:3000";

// Server image load url
// export const serverImageUrl =
// "https://elitepro-hi-re-backend-e3f64aevz-skmamunkhan072.vercel.app/";
export const serverImageUrl = "https://hire.server.elite-professionals.in";
// export const serverImageUrl = "http://localhost:8080";
